<?php
include('config.php')
?>
<!DOCTYPE html PUBLIC >
<html >
    <head>
          <head>
      <meta charset="utf-8">
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Spectre.css CSS Framework is a lightweight, responsive and modern CSS framework for faster and extensible development. Spectre provides basic styles for typography and elements, flexbox based responsive layout system, pure CSS components and utilities with best practice coding and consistent design language.">
    <link rel="shortcut icon" href="../img/favicons/favicon.ico">
    <link rel="icon" href="../img/favicons/favicon.png">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="stylesheet" href="docs.min.css">
        
    </head>
        <title>Espace membre</title>
    </head>
    <body>
    	  </head>
        <div class="section bg-gray">
            <br>
            <br>
      <H1><center>Espace Documentaire</center></H1>
    </div>
<?php
//On affiche un message de bienvenue, si lutilisateur est connecte, on affiche son pseudo
?>
<h2>Bienvenue sur votre session d'administration <b><?php if(isset($_SESSION['username'])){echo ' '.htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8');} ?></b></h2><br />
Bienvenue <br />
<br>
<br>
Vous pouvez <a href="users.php">voir la liste des utilisateurs</a>.<br /><br />
<br /><br />




<form method="post" action="reception.php" enctype="multipart/form-data">
     <div><center>

     </center></div>
     
</form>




<?php
//Si lutilisateur est connecte, on lui donne un lien pour modifier ses informations, pour voir ses messages et un pour se deconnecter
if(isset($_SESSION['username']))
{
?>
<a href="edit_infos.php"></a><br />
<a href="connexion2.php"></a>
<button class="btn"><a href="connexion2.php">Se d&eacute;connecter</a></button>

<?php
}
else
{
//Sinon, on lui donne un lien pour sinscrire et un autre pour se connecter
?>
<a href="sign_up.php">Inscription</a><br />
<a href="connexion.php">Se connecter</a>
<?php
}
?>
		</div>
		<button class="btn"><a href="index.html">quitter l'espace </a></button>
        <br>
        <br>

	</body>
</html>