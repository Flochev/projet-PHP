<?php

$destinataire = 'boite de l entreprise' ;
 
// copie ? (envoie une copie au visiteur)
$copie = 'oui';
 
// Action du formulaire (si votre page a des paramètres dans l'URL)

$form_action = '';
 

$message_envoye = "Votre message nous est bien parvenu !";
$message_non_envoye = "L'envoi du mail a échoué, veuillez réessayer SVP.";
 

$message_formulaire_invalide = "Vérifiez que tous les champs soient bien remplis et que l'email soit sans erreur.";
 

function Rec($text)
{
  $text = htmlspecialchars(trim($text), ENT_QUOTES);
  if (1 === get_magic_quotes_gpc())
  {
    $text = stripslashes($text);
  }
 
  $text = nl2br($text);
  return $text;
};
 

function IsEmail($email)
{
  $value = preg_match('/^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9_](?:[a-zA-Z0-9_\-](?!\.)){0,61}[a-zA-Z0-9_-]?\.)+[a-zA-Z0-9_](?:[a-zA-Z0-9_\-](?!$)){0,61}[a-zA-Z0-9_]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/', $email);
  return (($value === 0) || ($value === false)) ? false : true;
}

$nom     = (isset($_POST['nom']))     ? Rec($_POST['nom'])     : '';
$email   = (isset($_POST['email']))   ? Rec($_POST['email'])   : '';
$objet   = (isset($_POST['objet']))   ? Rec($_POST['objet'])   : '';
$message = (isset($_POST['message'])) ? Rec($_POST['message']) : '';
 

$email = (IsEmail($email)) ? $email : ''; // soit l'email est vide si erroné, soit il vaut l'email entré
$err_formulaire = false; // sert pour remplir le formulaire en cas d'erreur si besoin
 
if (isset($_POST['envoi']))
{
  if (($nom != '') && ($email != '') && ($objet != '') && ($message != ''))
  {

    $headers  = 'From:'.$nom.' <'.$email.'>' . "\r\n";

 
    if ($copie == 'oui')
    {
      $cible = $destinataire.';'.$email;
    }
    else
    {
      $cible = $destinataire;
    };
 

    $caracteres_speciaux     = array('&#039;', '&#8217;', '&quot;', '<br>', '<br />', '&lt;', '&gt;', '&amp;', '…',   '&rsquo;', '&lsquo;');
    $caracteres_remplacement = array("'",      "'",        '"',      '',    '',       '<',    '>',    '&',     '...', '>>',      '<<'     );
 
    $objet = html_entity_decode($objet);
    $objet = str_replace($caracteres_speciaux, $caracteres_remplacement, $objet);
 
    $message = html_entity_decode($message);
    $message = str_replace($caracteres_speciaux, $caracteres_remplacement, $message);
 

    $num_emails = 0;
    $tmp = explode(';', $cible);
    foreach($tmp as $email_destinataire)
    {
      if (mail($email_destinataire, $objet, $message, $headers))
        $num_emails++;
    }
 
    if ((($copie == 'oui') && ($num_emails == 2)) || (($copie == 'non') && ($num_emails == 1)))
    {
      echo '<p>'.$message_envoye.'</p>';
    }
    else
    {
      echo '<p>'.$message_non_envoye.'</p>';
    };
  }
  else
  {

    echo '<p>'.$message_formulaire_invalide.'</p>';
    $err_formulaire = true;
  };
}; 
 
if (($err_formulaire) || (!isset($_POST['envoi'])))
{

  echo '
  <form id="contact" method="post" action="'.$form_action.'">
  <fieldset><legend>Vos coordonnees</legend>
    <p><label for="nom">Nom :</label><input type="text" id="nom" name="nom" value="'.stripslashes($nom).'" /></p>
    <p><label for="email">Email :</label><input type="text" id="email" name="email" value="'.stripslashes($email).'" /></p>
  </fieldset>
 
  <fieldset><legend>Votre message :</legend>
    <p><label for="objet">Objet :</label><input type="text" id="objet" name="objet" value="'.stripslashes($objet).'" /></p>
    <p><label for="message">Message :</label><textarea id="message" name="message" cols="30" rows="8">'.stripslashes($message).'</textarea></p>
  </fieldset>
 
  <div style="text-align:center;"><input type="submit" name="envoi" value="Envoyer le formulaire !" /></div>
  </form>';
};
?>