<?php
   
   $userName=$_POST["userName"];
    $password=$_POST["password"];

if ("secretaire" == $userName AND "azerty" == $password ){ 
session_start("location:adminzone.php");
    
    echo("vous étes bien connecté");
    header("location:adminzone.php");
    }
    
else{
    header ("location:loginadmin.php");
    }
?>